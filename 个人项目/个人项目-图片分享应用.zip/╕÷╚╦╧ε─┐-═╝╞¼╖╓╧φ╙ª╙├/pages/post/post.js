// pages/post/post.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    images: [],
  },
  upload: function()
  {
    var that = this;
    var images = this.data.images;

    wx.chooseImage({
      count: 9,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],

      success: function (res) {
        const tempFilePaths = res.tempFilePaths
        var images = that.data.images;

        wx.saveFile({
          tempFilePath: tempFilePaths[0],

          success(res) {
            const savedFilePath = res.savedFilePath
            //console.log(savedFilePath)

            wx.getSavedFileList({
              success(res) {
                //console.log(res.fileList)
                for(var i = 0;i < res.fileList.length; i++)
                {
                  app.globalData.images[i] = res.fileList[i].filePath
                  images[i] = app.globalData.images[i]
                }
                console.log(images)
              }
            })
            
            wx.showToast({
              title: '发布成功',
            })
          }
        })
      }
    })
    this.setData({
      images: app.globalData.images
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})